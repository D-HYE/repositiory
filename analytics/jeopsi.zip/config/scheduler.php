<?php
return [
    'actable'        => 'abled',
    'disabledReason' => '가능',
    'serverIp'       => '133.186.250.249',
];