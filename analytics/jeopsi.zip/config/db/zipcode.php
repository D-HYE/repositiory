<?php
/**
 * 디비접속 정보
 *
 * @zend
 * @version   1.0
 * @since     1.0
 * @copyright Copyright (c), Godosoft
 */

return [
    'host' => 'zipcode.godo.co.kr',
    'username' => 'zipcode',
    'password' => 'dlskandnvusqjsgh',
    'database' => 'zipcode',
];
