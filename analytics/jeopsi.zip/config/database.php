<?php
/**
 * 디비접속 정보
 * @version 1.0
 * @since 1.0
 * @copyright Copyright (c), Godosoft
 */

return [
    'host' => '10.1.0.89',
    'username' => 'jeob1847',
    'password' => 'jeobsi114',
    'database' => 'jeobsi22_godomall_com',
];
