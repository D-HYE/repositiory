<?php
/* 
 * CDN
 * 
 * [주의] !! 반드시 아래 주석 확인 할 것 !!
 * 
 *  - RETURN CONFIG -
 * (Boolean)true: CDN ON
 * (Boolean)false: CDN OFF
 */
return true;
