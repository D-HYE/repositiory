[{rc_mallNm}] {rc_expirationFl}년 이상 미접속으로 인한 휴면회원 전환 사전 안내드립니다.
