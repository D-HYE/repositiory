$(document).ready(function(){
    const [ category_chosen , boardArea ] = [ $('#categoryh2_chosen  .chosen-single'), $('.board_zone_sec') ];
    const _bodytag = $('body');
    

    const lenselectnotice =[
        {
            bodycls : 'body-us',
            selectCate : 'Eng'
        },
        {
            bodycls : 'body-cn',
            selectCate : 'Chi'
        },
        {
            bodycls : 'body-jp',
            selectCate : 'Jan'
        },
        {
            bodycls : 'body-kr',
            selectCate : 'Kor'
        }

     ]
    
   if( category_chosen.length > 0 && boardArea.length > 0  ){

    const allcate = $('#categoryh2 option:selected').val(); //언어선택

    if(allcate == '' ){
        $('#board_notice').addClass('all')
    }
    
    // lenselectnotice.forEach((ea, index) => {
    //     // all이고 해외몰구분되면
    //     const lenselect = ea.selectCate; 
    //        if( _bodytag.hasClass(ea.bodycls) && allcate !== ea.selectCate ) { //글로벌몰에 매치되는 언어 저장하기              
            
    //         console.log(ea.bodycls,  lenselect)
    //        // $('#categoryh2').val(lenselect).change();
    
    //        }
    //     //    else{ //매치되지 않는다면
    //     //     console.log(ea.bodycls,  lenselect)
    //     //    }         
    //     }
    // )

    
   }
})